//
//  ViewController.swift
//  Flix
//
//  Created by Riik Acharya on 2/4/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

